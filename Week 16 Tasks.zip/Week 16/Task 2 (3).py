from web3 import Web3


w3 = Web3(Web3.HTTPProvider("https://127.0.0.1:8545"))

account = w3.eth.account[0]
w3.eth.default_account = account

abi = "[YOUR CONTRACT ABI]"
bytecode = "[YOUR CONTRACT BYTECODE]"

simple_storage = w3.eth.contract(abi=abi, bytecode=bytecode)

gas_estimate = simple_storage.constructor().estimate_gas()

tx_hash = simple_storage.constructor().transact({"from": account, "gas": gas_estimate})
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

print(f"Contract deployed at address: {tx_receipt.contract_address}")

contract_address = tx_receipt.contractAddress
simple_storage = w3.eth.contract(address=contract_address, abi=abi)

tx_hash = simple_storage.functions.set(42).transact()
w3.eth.wait_for_transaction_receipt(tx_hash)

stored_value = simple_storage.functions.get().call()
print(f"Stored value: {stored_value}")