from web3 import Web3


w3 = Web3(Web3.HTTPProvider("https://127.0.0.1:8545"))

if w3.is_connected():
    print("Connected to Ethereum node.")
else:
    print("Failed to connect.")

accounts = w3.eth.accounts
print(f"Account: {accounts}")

balance = w3.eth.get_balance(accounts[0])
print(f"Balance of first account is {w3.fromWei(balance, 'ether')} ETH.")