from web3 import Web3


infura_url = "https://mainnet.infura.io/v3/7a127280d5ea44a285d4e36f5f65b555"
web3 = Web3(Web3.HTTPProvider(infura_url))

if web3.is_connected():
    print("Connected to Ethereum network.")
else:
    print("Connection failed.")

latest_block = web3.eth.get_block("latest")
print(f"Latest Block Number: {latest_block["number"]}")
print(f"Block Timestamp: {latest_block["timestamp"]}")
print(f"Block Transactions: {latest_block["transactions"]}")

block_number = 17000000
block = web3.eth.get_block(block_number)
print(f"Block {block_number}: Info: {block}")

transaction_hash = block["transactions"][0]
transaction = web3.eth.get_transaction(transaction_hash)
print(f"Transaction Details: {transaction}")

gas_price = web3.from_wei(transaction["gasPrice"], "gwei")
print(f"Gas Price: {gas_price}")

gas_limit = transaction["gas"]
print(f"Gas Limit: {gas_limit}")

receipt = web3.eth.get_transaction_receipt(transaction_hash)
gas_used = receipt["gasUsed"]
print(f"Gas Used: {gas_used}")

for tx_hash in block["transactions"]:
    tx = web3.eth.get_transaction(tx_hash)
    print(f"From: {tx["from"]}, To: {tx["to"]}, Value: {web3.from_wei(tx["value"], "ether")} ETH.")